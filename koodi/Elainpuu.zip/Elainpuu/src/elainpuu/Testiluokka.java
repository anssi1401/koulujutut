package elainpuu;

/**
 *
 * @author anssi1401
 */
public class Testiluokka {

    public static void main(String[] args) {
        Ihminen jaska = new Ihminen();
        Kissa misse = new Kissa();
        Opiskelija olli = new Opiskelija();
        Opettaja martti = new Opettaja();
        
        jaska.setIka(5);
        System.out.println(jaska.getIka());
        
        misse.setPorroisyys(true);
        misse.isPorroisyys();
        
        martti.setJalkojen_maara(3);
        System.out.println(martti.getJalkojen_maara());
        
        olli.liikun();
        olli.setOpiskelijanro(121);
        System.out.println(olli.getOpiskelijanro());
        
    }
}
