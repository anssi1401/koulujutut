import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Main {

    public static void main(String[] args) {

        String driver = "org.apache.derby.jdbc.EmbeddedDriver";
        Connection con;

        try {
            Class.forName(driver).newInstance(); // rekisteröidään tietokanta ajuri
        } catch (Exception ex) {
            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }

        // Luodaanpa taulu
        try {
            con = DriverManager.getConnection("jdbc:derby:testitk;create=true"); // Luodaan yhteys tietokantaan

            // Luodaan tietokantaan taulu TUOTTEET
            Statement stmt = null;
            String sql;
            sql = "CREATE TABLE TUOTTEET ("
                    + "TID INTEGER NOT NULL PRIMARY KEY,"
                    + "NIMI VARCHAR(40) NOT NULL,"
                    + "HINTA FLOAT,"
                    + "LKM INTEGER DEFAULT 0 )";

            stmt = con.createStatement();
            try {
                stmt.executeUpdate(sql);
            } catch (Exception ex) {
                //Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
            }

            System.out.println("pääsin yli!!");

            // Kirjoitetaan Tauluun tietoa
            sql = "INSERT INTO TUOTTEET "
                    + "VALUES(1, 'Korppu', 3.5, 10)";
            try {
                stmt.executeUpdate(sql);

                sql = "INSERT INTO TUOTTEET "
                        + "VALUES(2, 'Lerppu', 5.25, 5)";
                stmt.executeUpdate(sql);
                sql = "INSERT INTO TUOTTEET "
                        + "VALUES(3, 'CD', 100, 50)";
                stmt.executeUpdate(sql);
            } catch (Exception ex) {
                //Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
            }

            System.out.println("Pääsin tännekin");

            // Luetaan Taulusta tietoa
            sql = "SELECT * FROM TUOTTEET";
            ResultSet rs = stmt.executeQuery(sql);

            // Yritetään lukea tietoja ennen rs.next():iä
//            try {
//                int i = rs.getInt("TID");
//                System.out.println("i: " + i + "\n");
//            } catch (Exception ex) {
//                System.out.println("*** Ei onnistu noin vain!!! ***");
//                //Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
//            }

            //Käydään tulokset läpi
            while (rs.next()) {
                int i = rs.getInt("TID");
                System.out.println("i: " + i);
            }

            // suljetaan ResultSet, Statement ja Connection
            rs.close();
            stmt.close();
            con.close();
        } catch (Exception ex) {
            //Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
